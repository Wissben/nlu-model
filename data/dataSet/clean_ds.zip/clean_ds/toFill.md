## intent:print
- print a [](color) [](object)
- print a [](size) [](object)
- print a [](size) [](color) [](object)
- print a [](color) thing
- print a [](color) painted [](object)
- print a [](size) sized [](object)
- print a [](size) [](color) painted [](object)
- print a [](size) sized [](color) [](object)
- print a [](color) colored [](object)
- print a [](size) [](color) colored [](object)
- print a [](color) painted thing

- try to print a [](color) [](object)
- try to print a [](size) [](object)
- try to print a [](size) [](color) [](object)
- try to print a [](color) thing
- try to print a [](color) painted [](object)
- try to print a [](size) sized [](object)
- try to print a [](size) [](color) painted [](object)
- try to print a [](size) sized [](color) [](object)
- try to print a [](color) colored [](object)
- try to print a [](size) [](color) colored [](object)
- try to print a [](color) painted thing

- could you please print a [](color) [](object)
- could you please print a [](size) [](object)
- could you please print a [](size) [](color) [](object)
- could you please print a [](color) thing
- could you please print a [](color) painted [](object)
- could you please print a [](size) sized [](object)
- could you please print a [](size) [](color) painted [](object)
- could you please print a [](size) sized [](color) [](object)
- could you please print a [](color) colored [](object)
- could you please print a [](size) [](color) colored [](object)
- could you please print a [](color) painted thing



- can you please print a [](color) [](object)
- can you please print a [](size) [](object)
- can you please print a [](size) [](color) [](object)
- can you please print a [](color) thing
- can you please print a [](color) painted [](object)
- can you please print a [](size) sized [](object)
- can you please print a [](size) [](color) painted [](object)
- can you please print a [](size) sized [](color) [](object)
- can you please print a [](color) colored [](object)
- can you please print a [](size) [](color) colored [](object)
- can you please print a [](color) painted thing


- can you print a [](color) [](object)
- can you print a [](size) [](object)
- can you print a [](size) [](color) [](object)
- can you print a [](color) thing
- can you print a [](color) painted [](object)
- can you print a [](size) sized [](object)
- can you print a [](size) [](color) painted [](object)
- can you print a [](size) sized [](color) [](object)
- can you print a [](color) colored [](object)
- can you print a [](size) [](color) colored [](object)
- can you print a [](color) painted thing

- make a [](color) [](object)
- make a [](size) [](object)
- make a [](size) [](color) [](object)
- make a [](color) thing
- make a [](color) painted [](object)
- make a [](size) sized [](object)
- make a [](size) [](color) painted [](object)
- make a [](size) sized [](color) [](object)
- make a [](color) colored [](object)
- make a [](size) [](color) colored [](object)
- make a [](color) painted thing

- i want a [](color) [](object)
- i want a [](size) [](object)
- i want a [](size) [](color) [](object)
- i want a [](color) thing
- i want a [](color) painted [](object)
- i want a [](size) sized [](object)
- i want a [](size) [](color) painted [](object)
- i want a [](size) sized [](color) [](object)
- i want a [](color) colored [](object)
- i want a [](size) [](color) colored [](object)
- i want a [](color) painted thing

- give me a [](color) [](object)
- give me a [](size) [](object)
- give me a [](size) [](color) [](object)
- give me a [](color) thing
- give me a [](color) painted [](object)
- give me a [](size) sized [](object)
- give me a [](size) [](color) painted [](object)
- give me a [](size) sized [](color) [](object)
- give me a [](color) colored [](object)
- give me a [](size) [](color) colored [](object)
- give me a [](color) painted thing

- produce a [](color) [](object)
- produce a [](size) [](object)
- produce a [](size) [](color) [](object)
- produce a [](color) thing
- produce a [](color) painted [](object)
- produce a [](size) sized [](object)
- produce a [](size) [](color) painted [](object)
- produce a [](size) sized [](color) [](object)
- produce a [](color) colored [](object)
- produce a [](size) [](color) colored [](object)
- produce a [](color) painted thing

- i need a [](color) [](object)
- i need a [](size) [](object)
- i need a [](size) [](color) [](object)
- i need a [](color) thing
- i need a [](color) painted [](object)
- i need a [](size) sized [](object)
- i need a [](size) [](color) painted [](object)
- i need a [](size) sized [](color) [](object)
- i need a [](color) colored [](object)
- i need a [](size) [](color) colored [](object)
- i need a [](color) painted thing


## intent:inform
- let it be [](size)
- let it be [](color)
- let it be [](object)
- let it be [](size) and [](color)
- let it be [](color) and [](size)
- let it be a [](color) [](object)
- let it be a [](size) [](object)
- let it be a [](color) [](size) [](object)
- let it be a [](size) [](color) [](object)


- let it be [](size) sized
- let it be [](color) painted
- let it be [](size) sized and [](color)
- let it be [](color) and [](size)sized
- let it be [](size) sized and [](color) painted
- let it be a [](color) painted [](object)
- let it be a [](size) sized [](object)
- let it be a [](color) painted [](size) [](object)
- let it be a [](size) sized [](color) [](object)

- it is [](size)
- it is [](color)
- it is [](object)
- it is [](size) and [](color)
- it is [](color) and [](size)
- it is a [](color) [](object)
- it is a [](size) [](object)
- it is a [](color) [](size) [](object)
- it is a [](size) [](color) [](object)


- it is [](size) sized
- it is [](color) painted
- it is [](size) sized and [](color)
- it is [](color) and [](size)sized
- it is [](size) sized and [](color) painted
- it is a [](color) painted [](object)
- it is a [](size) sized [](object)
- it is a [](color) painted [](size) [](object)
- it is a [](size) sized [](color) [](object)

- it's [](size)
- it's [](color)
- it's [](object)
- it's [](size) and [](color)
- it's [](color) and [](size)
- it's a [](color) [](object)
- it's a [](size) [](object)
- it's a [](color) [](size) [](object)
- it's a [](size) [](color) [](object)


- it's [](size) sized
- it's [](color) painted
- it's [](size) sized and [](color)
- it's [](color) and [](size)sized
- it's [](size) sized and [](color) painted
- it's a [](color) painted [](object)
- it's a [](size) sized [](object)
- it's a [](color) painted [](size) [](object)
- it's a [](size) sized [](color) [](object)

- make sure it is [](size)
- make sure it is [](color)
- make sure it is [](object)
- make sure it is [](size) and [](color)
- make sure it is [](color) and [](size)
- make sure it is a [](color) [](object)
- make sure it is a [](size) [](object)
- make sure it is a [](color) [](size) [](object)
- make sure it is a [](size) [](color) [](object)


- make sure it is [](size) sized
- make sure it is [](color) painted
- make sure it is [](size) sized and [](color)
- make sure it is [](color) and [](size)sized
- make sure it is [](size) sized and [](color) painted
- make sure it is a [](color) painted [](object)
- make sure it is a [](size) sized [](object)
- make sure it is a [](color) painted [](size) [](object)
- make sure it is a [](size) sized [](color) [](object)

- make sure it's [](size)
- make sure it's [](color)
- make sure it's [](object)
- make sure it's [](size) and [](color)
- make sure it's [](color) and [](size)
- make sure it's a [](color) [](object)
- make sure it's a [](size) [](object)
- make sure it's a [](color) [](size) [](object)
- make sure it's a [](size) [](color) [](object)


- make sure it's [](size) sized
- make sure it's [](color) painted
- make sure it's [](size) sized and [](color)
- make sure it's [](color) and [](size)sized
- make sure it's [](size) sized and [](color) painted
- make sure it's a [](color) painted [](object)
- make sure it's a [](size) sized [](object)
- make sure it's a [](color) painted [](size) [](object)
- make sure it's a [](size) sized [](color) [](object)


## intent:ask
- what [](color) is it
- what [](size) is it
- what [](object) is it
- can you repeat please
- do you want to confirm
- do you really want to cancel
## intent:deny
- deny
- don't
- do not
- it's not
- it is not
- i want that
- i desire that
- i agree
- i want that
- that is fine
- that is correct
- that is what i want
- you understood me
- that is right
- that is what i mean
- want that
- im ok with that
- ok its good
- im good with that
- ok its fine
- is good
- it is fine
- im ok with this
- im good with this
- that's not right
- that's not good
- incorrect
- don't do that
- sounds bad to me
- sounds not good to me
- sounds wrong
- sounds wrong to me
- no
- no not that
- nope
- nah
- not really
- absolutley not
- no it's not
- not what i wanted
- no i would prefer not
- i would prefer not
- not necessary
- i would prefer not to
- Just don't do that
- no you can't
- This would be probably a bad idea
- i deny it
- no i refuse
- definitely not
- surely not
- ideally no
- sounds bad
- sounds bad to me			
- its not ok				
- its not alright			
- its not okay
- no it is not
- no its not correct
- bad
- wrong
- its bad
- its not good						
## intent:confirm
- yes
- yep
- yeah
- sure
- absolutely
- that's it
- perfect
- this is it
- totally approve
- approve
- i approve
- yes i approve
- yes approve
- okay
- settle
- yes i totally approve
- should do it
- it should do it
- sounds good
- alright
- right
- okay thanks
- you understood me
- good

## intent:cancel
- cancel
- abolish
- abort
- annul
- break off
- cut
- destroy
- eliminate
- kill
- remove
- repeal
- rescind
- would you please cancel
- would your abolish
- would your abort
- would your annul
- would your break off
- would your cut
- would your destroy
- would your eliminate
- would your kill
- would your remove
- would your epeal
- would you please rescind
- can you please cancel
- can you please abolish
- can you please abort
- can you please annul
- can you please break off
- can you please cut
- can you please destroy
- can you please eliminate
- can you please kill
- can you please remove
- can you please repeal
- can you please rescind
